from myservice.app import app   # NOQA
