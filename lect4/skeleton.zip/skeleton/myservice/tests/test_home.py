import unittest


class TestSomething(unittest.TestCase):

    def test_my_view(self):
        pass
